-- ============================================
-- 10KP Supabase Setup
-- Run this in the Supabase SQL Editor
-- ============================================

-- 1. Tags table (populate with your tags later)
create table if not exists public.tags (
  id uuid default gen_random_uuid() primary key,
  name text not null unique,
  created_at timestamptz default now()
);

-- 2. Pitches table
create table if not exists public.pitches (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  name text not null,
  role text,
  schools text[] default '{}',
  title text not null,
  description text not null,
  file_path text,
  file_name text,
  created_at timestamptz default now()
);

-- Extend pitches for Mux video processing workflow
alter table public.pitches
  add column if not exists file_type text default 'file',
  add column if not exists mux_upload_id text,
  add column if not exists mux_asset_id text,
  add column if not exists mux_playback_id text,
  add column if not exists mux_error text,
  add column if not exists mux_status text default 'pending';

create index if not exists pitches_mux_status_idx on public.pitches (mux_status);

-- Content moderation columns
alter table public.pitches
  add column if not exists moderation_status text not null default 'pending',
  add column if not exists moderation_reason text,
  add column if not exists moderation_flags jsonb not null default '[]'::jsonb,
  add column if not exists moderation_transcript text,
  add column if not exists moderation_reviewed_by text,
  add column if not exists moderation_reviewed_at timestamptz,
  add column if not exists moderation_priority integer not null default 0,
  add column if not exists moderation_checked_at timestamptz;

alter table public.pitches
  drop constraint if exists pitches_moderation_status_check;
alter table public.pitches
  add constraint pitches_moderation_status_check
  check (moderation_status in ('pending','approved','rejected','flagged','errored'));

create index if not exists pitches_moderation_status_idx
  on public.pitches (moderation_status);
create index if not exists pitches_moderation_priority_idx
  on public.pitches (moderation_priority desc, created_at desc);

-- Prevent non-service-role updates from mutating moderation_* fields.
create or replace function public.pitches_protect_moderation()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if current_setting('request.jwt.claim.role', true) = 'service_role' then
    return new;
  end if;
  new.moderation_status := old.moderation_status;
  new.moderation_reason := old.moderation_reason;
  new.moderation_flags := old.moderation_flags;
  new.moderation_transcript := old.moderation_transcript;
  new.moderation_reviewed_by := old.moderation_reviewed_by;
  new.moderation_reviewed_at := old.moderation_reviewed_at;
  new.moderation_priority := old.moderation_priority;
  new.moderation_checked_at := old.moderation_checked_at;
  return new;
end;
$$;

drop trigger if exists pitches_protect_moderation_trg on public.pitches;
create trigger pitches_protect_moderation_trg
  before update on public.pitches
  for each row execute function public.pitches_protect_moderation();

-- ─── Moderation v2 columns (see migrations/20260723_moderation_v2.sql
--     for the full state model and comments) ──────────────────────────
alter table public.pitches
  add column if not exists media_status text not null default 'uploading',
  add column if not exists transcript_status text not null default 'not_started',
  add column if not exists transcript text,
  add column if not exists transcript_language text,
  add column if not exists transcript_last_error text,
  add column if not exists moderation_state text not null default 'not_started',
  add column if not exists moderation_version integer not null default 2,
  add column if not exists moderation_source text,
  add column if not exists moderation_started_at timestamptz,
  add column if not exists moderation_completed_at timestamptz,
  add column if not exists moderation_summary text,
  add column if not exists moderation_reasons jsonb not null default '[]'::jsonb,
  add column if not exists moderation_categories jsonb not null default '[]'::jsonb,
  add column if not exists moderation_scores jsonb not null default '{}'::jsonb,
  add column if not exists moderation_admin_notes text,
  add column if not exists moderation_attempt_count integer not null default 0,
  add column if not exists moderation_last_attempt_at timestamptz,
  add column if not exists moderation_next_attempt_at timestamptz,
  add column if not exists moderation_last_error text,
  add column if not exists visual_moderation_status text not null default 'not_applicable',
  add column if not exists visual_moderation_result jsonb,
  add column if not exists transcript_moderation_status text not null default 'not_applicable',
  add column if not exists transcript_moderation_result jsonb,
  add column if not exists mux_moderation_job_id text,
  add column if not exists mux_moderation_result jsonb;

create table if not exists public.moderation_webhook_events (
  id uuid default gen_random_uuid() primary key,
  provider text not null,
  event_id text not null,
  event_type text,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  processing_status text not null default 'received',
  last_error text,
  attempt_count integer not null default 0,
  payload jsonb,
  constraint moderation_webhook_events_provider_event_id_key unique (provider, event_id)
);
alter table public.moderation_webhook_events enable row level security;

create table if not exists public.moderation_audit (
  id uuid default gen_random_uuid() primary key,
  pitch_id uuid not null references public.pitches(id) on delete cascade,
  action text not null,
  previous_state text,
  new_state text,
  reviewed_by text,
  reason text,
  admin_notes text,
  details jsonb,
  created_at timestamptz not null default now()
);
alter table public.moderation_audit enable row level security;

create table if not exists public.mux_webhook_logs (
  id uuid default gen_random_uuid() primary key,
  created_at timestamptz default now(),
  event_type text,
  status text not null,
  upload_id text,
  asset_id text,
  playback_id text,
  passthrough text,
  matched_pitch_id uuid references public.pitches(id) on delete set null,
  matched_by text,
  message text,
  payload jsonb
);

create index if not exists mux_webhook_logs_created_at_idx
  on public.mux_webhook_logs (created_at desc);

-- 3. Pitch-Tags join table (many-to-many)
create table if not exists public.pitch_tags (
  pitch_id uuid references public.pitches(id) on delete cascade,
  tag_id uuid references public.tags(id) on delete cascade,
  primary key (pitch_id, tag_id)
);

-- ============================================
-- Row Level Security (RLS)
-- ============================================

-- Enable RLS on all tables
alter table public.tags enable row level security;
alter table public.pitches enable row level security;
alter table public.pitch_tags enable row level security;
alter table public.mux_webhook_logs enable row level security;

-- Tags: anyone authenticated can read
create policy "Anyone can read tags"
  on public.tags for select
  to authenticated
  using (true);

-- Pitches: users can insert their own
create policy "Users can insert own pitches"
  on public.pitches for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Pitches: users can read their own
create policy "Users can read own pitches"
  on public.pitches for select
  to authenticated
  using (auth.uid() = user_id);

-- Pitches: users can update their own
create policy "Users can update own pitches"
  on public.pitches for update
  to authenticated
  using (auth.uid() = user_id);

-- Pitch Tags: users can insert for their own pitches
create policy "Users can insert own pitch tags"
  on public.pitch_tags for insert
  to authenticated
  with check (
    exists (
      select 1 from public.pitches
      where pitches.id = pitch_id
        and pitches.user_id = auth.uid()
    )
  );

-- Pitch Tags: users can read their own pitch tags
create policy "Users can read own pitch tags"
  on public.pitch_tags for select
  to authenticated
  using (
    exists (
      select 1 from public.pitches
      where pitches.id = pitch_id
        and pitches.user_id = auth.uid()
    )
  );

-- ============================================
-- Storage Bucket
-- ============================================

-- Create the pitch-files bucket (run once)
insert into storage.buckets (id, name, public)
values ('pitch-files', 'pitch-files', false)
on conflict (id) do nothing;

-- Storage policy: authenticated users can upload to their own folder
create policy "Users can upload own pitch files"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'pitch-files'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- Storage policy: users can read their own files
create policy "Users can read own pitch files"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'pitch-files'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- ============================================
-- 4. Competition Settings table (single-row)
-- ============================================

create table if not exists public.competition_settings (
  id uuid default gen_random_uuid() primary key,
  competition_date timestamptz,
  updated_at timestamptz default now()
);

-- Enable RLS
alter table public.competition_settings enable row level security;

-- Anyone authenticated can read the competition date
create policy "Anyone can read competition settings"
  on public.competition_settings for select
  to authenticated
  using (true);

-- Note: Insert/update handled via service role key in API routes (admin-only)

-- ============================================
-- 5. Announcements table (admin-managed)
-- ============================================

create table if not exists public.announcements (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  content text not null,
  is_published boolean not null default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists announcements_updated_at_idx
  on public.announcements (updated_at desc);

create index if not exists announcements_is_published_idx
  on public.announcements (is_published);

alter table public.announcements enable row level security;

-- ============================================
-- 6. Admin broadcast history (optional but recommended)
-- ============================================

create table if not exists public.admin_broadcast_campaigns (
  id uuid default gen_random_uuid() primary key,
  created_at timestamptz not null default now(),
  created_by text,
  subject text not null,
  body_text text not null,
  recipient_scope text not null default 'all',
  confirmed_filter text not null default 'all',
  recipient_count integer not null default 0,
  resend_segment_id text,
  resend_broadcast_id text,
  status text not null default 'sent',
  details jsonb not null default '{}'::jsonb
);

create index if not exists admin_broadcast_campaigns_created_at_idx
  on public.admin_broadcast_campaigns (created_at desc);

alter table public.admin_broadcast_campaigns enable row level security;

-- ============================================
-- Example: Insert some starter tags
-- (replace these with your actual tags later)
-- ============================================
-- insert into public.tags (name) values
--   ('Technology'),
--   ('Healthcare'),
--   ('Finance'),
--   ('Education'),
--   ('Social Impact');
