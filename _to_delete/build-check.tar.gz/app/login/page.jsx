"use client";

import { useEffect, useState } from "react";
import { useAuth } from "../../lib/AuthContext";
import { supabase } from "../../lib/supabase";
import Link from "next/link";
import { useRouter } from "next/navigation";
import AuthShell, { AuthHeader } from "../../components/AuthShell";

export default function LoginPage() {
  const { signIn } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [focusedField, setFocusedField] = useState(null);
  const [resetSucceeded, setResetSucceeded] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setResetSucceeded(params.get("reset") === "success");
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    const { error: signInError } = await signIn(email, password);

    if (signInError) {
      setLoading(false);
      setError(signInError.message);
      return;
    }

    // Ask the server whether this account is an admin (env-var list OR
    // admin_users table) so admins added through the Settings tab also
    // land on /admin instead of /intake.
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch("/api/auth/is-admin", {
        headers: session?.access_token
          ? { Authorization: `Bearer ${session.access_token}` }
          : {},
      });
      const data = await res.json().catch(() => ({}));
      setLoading(false);
      router.push(data?.isAdmin ? "/admin" : "/intake");
    } catch {
      setLoading(false);
      router.push("/intake");
    }
  };

  return (
    <AuthShell>
      <AuthHeader
        title="Welcome Back"
        subtitle={
          <>
            Sign in to your 10K Pitches account. You must use your{" "}
            <span className="text-white/75 font-medium">@umich.edu</span> email.
          </>
        }
      />

      {/* Error */}
      {error && (
        <div
          className="mb-5 flex items-start gap-3 p-3.5 text-sm rounded-xl"
          style={{
            color: "#fca5a5",
            background: "rgba(239, 68, 68, 0.12)",
            border: "1px solid rgba(239, 68, 68, 0.25)",
          }}
        >
          <svg className="w-5 h-5 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span>{error}</span>
        </div>
      )}
      {resetSucceeded && (
        <div
          className="mb-5 flex items-start gap-3 p-3.5 text-sm rounded-xl"
          style={{
            color: "#86efac",
            background: "rgba(34, 197, 94, 0.12)",
            border: "1px solid rgba(34, 197, 94, 0.25)",
          }}
        >
          <svg className="w-5 h-5 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span>Password updated. Log in with your new password.</span>
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Email field */}
        <div>
          <label htmlFor="email" className="block text-sm font-semibold text-white/80 mb-2">
            Email
          </label>
          <div
            className="relative rounded-xl transition-all duration-200"
            style={{
              border: focusedField === "email" ? "2px solid #FFCB05" : "2px solid rgba(255,255,255,0.12)",
              boxShadow: focusedField === "email" ? "0 0 0 3px rgba(255,203,5,0.2)" : "none",
              background: "rgba(255,255,255,0.05)",
            }}
          >
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
              <svg className="w-5 h-5 transition-colors" style={{ color: focusedField === "email" ? "#FFCB05" : "rgba(255,255,255,0.35)" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            </div>
            <input
              id="email"
              type="email"
              placeholder="uniqname@umich.edu"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onFocus={() => setFocusedField("email")}
              onBlur={() => setFocusedField(null)}
              required
              className="w-full pl-11 pr-3 py-3 bg-transparent rounded-xl text-sm text-white placeholder-white/30 focus:outline-none"
            />
          </div>
        </div>

        {/* Password field */}
        <div>
          <div className="flex items-center justify-between gap-3 mb-2">
            <label htmlFor="password" className="block text-sm font-semibold text-white/80">
              Password
            </label>
            <Link href="/forgot-password" className="text-xs font-medium text-white/45 hover:text-maize transition-colors">
              Forgot password?
            </Link>
          </div>
          <div
            className="relative rounded-xl transition-all duration-200"
            style={{
              border: focusedField === "password" ? "2px solid #FFCB05" : "2px solid rgba(255,255,255,0.12)",
              boxShadow: focusedField === "password" ? "0 0 0 3px rgba(255,203,5,0.2)" : "none",
              background: "rgba(255,255,255,0.05)",
            }}
          >
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
              <svg className="w-5 h-5 transition-colors" style={{ color: focusedField === "password" ? "#FFCB05" : "rgba(255,255,255,0.35)" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <input
              id="password"
              type={showPassword ? "text" : "password"}
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onFocus={() => setFocusedField("password")}
              onBlur={() => setFocusedField(null)}
              required
              className="w-full pl-11 pr-11 py-3 bg-transparent rounded-xl text-sm text-white placeholder-white/30 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center transition-colors"
              style={{ color: "rgba(255,255,255,0.35)" }}
              onMouseEnter={(e) => e.currentTarget.style.color = "rgba(255,255,255,0.7)"}
              onMouseLeave={(e) => e.currentTarget.style.color = "rgba(255,255,255,0.35)"}
              tabIndex={-1}
            >
              {showPassword ? (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L6.59 6.59m7.532 7.532l3.29 3.29M3 3l18 18" />
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              )}
            </button>
          </div>
        </div>

        {/* Submit button */}
        <button
          type="submit"
          disabled={loading}
          className="relative w-full py-3 text-sm font-semibold rounded-xl transition-all duration-200 overflow-hidden
            text-black hover:shadow-lg hover:-translate-y-0.5
            disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0 disabled:hover:shadow-none
            active:translate-y-0 active:shadow-md group"
          style={{ background: "#FFCB05" }}
        >
          <span className="relative z-10 flex items-center justify-center gap-2">
            {loading ? (
              <>
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Signing in...
              </>
            ) : (
              <>
                Log In
                <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </>
            )}
          </span>
          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        </button>
      </form>

      {/* Divider */}
      <div className="flex items-center gap-3 my-6">
        <div className="flex-1" style={{ borderTop: "1px solid rgba(255,255,255,0.1)" }} />
        <span
          className="text-[11px] uppercase tracking-wider"
          style={{ color: "rgba(255,255,255,0.35)" }}
        >
          New here?
        </span>
        <div className="flex-1" style={{ borderTop: "1px solid rgba(255,255,255,0.1)" }} />
      </div>

      {/* Sign up link */}
      <Link
        href="/signup"
        className="flex items-center justify-center w-full py-3 text-sm font-semibold rounded-xl transition-all duration-200 group"
        style={{
          border: "2px solid rgba(255,255,255,0.15)",
          color: "rgba(255,255,255,0.8)",
          background: "transparent",
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.borderColor = "#FFCB05";
          e.currentTarget.style.color = "#FFCB05";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)";
          e.currentTarget.style.color = "rgba(255,255,255,0.8)";
        }}
      >
        Create an account
        <svg className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
        </svg>
      </Link>
    </AuthShell>
  );
}
