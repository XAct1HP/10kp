"use client";

import { useState, useEffect, Fragment } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "../lib/AuthContext";
import PageBackground from "../components/PageBackground";
import SponsorSpotlight from "../components/SponsorSpotlight";
import homeHero from "../public/10kp_hero_image.png";

function useCountdown(targetDate) {
  const [timeLeft, setTimeLeft] = useState(null);

  useEffect(() => {
    if (!targetDate) return;
    const tick = () => {
      const diff = new Date(targetDate).getTime() - Date.now();
      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, past: true });
        return;
      }
      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((diff / (1000 * 60)) % 60),
        seconds: Math.floor((diff / 1000) % 60),
        past: false,
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [targetDate]);

  return timeLeft;
}

export default function Home() {
  const router = useRouter();
  const { user } = useAuth();
  const submitHref = user ? "/intake" : "/signup";
  const [competitionDate, setCompetitionDate] = useState(null);
  const [submissionDeadline, setSubmissionDeadline] = useState(null);

  // Determine which countdown target and label to show based on the
  // current phase:
  //   • pre-start:  competition hasn't started yet   -> "Competition starts in"
  //   • pre-close:  started but before deadline      -> "Time left to submit"
  //   • closed:     past the deadline                -> submissions closed
  //   • no dates:   nothing configured               -> countdown hidden
  const now = Date.now();
  const startTs = competitionDate ? new Date(competitionDate).getTime() : null;
  const closeTs = submissionDeadline ? new Date(submissionDeadline).getTime() : null;

  let phase = "none";
  let countdownTarget = null;
  let countdownLabel = "";
  if (startTs && now < startTs) {
    phase = "pre-start";
    countdownTarget = competitionDate;
    countdownLabel = "Competition starts in";
  } else if (closeTs && now < closeTs) {
    phase = "pre-close";
    countdownTarget = submissionDeadline;
    countdownLabel = "Time left to submit";
  } else if ((startTs && now >= startTs) || (closeTs && now >= closeTs)) {
    phase = "closed";
  }

  const timeLeft = useCountdown(countdownTarget);

  useEffect(() => {
    const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));
    if (hashParams.get("type") === "recovery" && hashParams.get("access_token")) {
      router.replace(`/reset-password${window.location.search}${window.location.hash}`);
      return;
    }

    async function fetchDates() {
      try {
        const res = await fetch("/api/admin/competition-date");
        const data = await res.json();
        if (data.competition_date) setCompetitionDate(data.competition_date);
        if (data.submission_deadline) setSubmissionDeadline(data.submission_deadline);
      } catch {
        // ignore
      }
    }
    fetchDates();
  }, [router]);

  const pad = (n) => String(n).padStart(2, "0");

  const countdownUnits = timeLeft && !timeLeft.past
    ? [
        { label: "Days", value: timeLeft.days },
        { label: "Hours", value: timeLeft.hours },
        { label: "Min", value: timeLeft.minutes },
        { label: "Sec", value: timeLeft.seconds },
      ]
    : null;

  return (
    <div className="relative min-h-[calc(100vh-5rem)] flex flex-col overflow-hidden">
      <PageBackground src={homeHero} priority quality={72} objectPosition="top" />
      {/* Gradient overlay - stronger on mobile for text readability */}
      <div
        className="absolute inset-0 lg:hidden"
        style={{
          background:
            "linear-gradient(to bottom, rgba(6,14,33,0.55) 0%, rgba(6,14,33,0.7) 45%, rgba(11,26,59,0.92) 85%, rgba(11,26,59,0.98) 100%)",
        }}
      />
      <div
        className="absolute inset-0 hidden lg:block"
        style={{
          background:
            "linear-gradient(to bottom, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.15) 30%, rgba(11,26,59,0.75) 85%, rgba(11,26,59,0.92) 100%)",
        }}
      />

      {/* Sponsor spotlight — top-right corner rotator, compact on mobile */}
      <SponsorSpotlight />

      {/* MOBILE LAYOUT (< lg)
          Reorganized so the sponsor disk owns the top-right corner: the hero
          image gets the upper half to breathe, and everything with words in it
          — countdown, headline, copy, CTAs — is grouped into one bottom stack.
          The countdown shrank from four huge numerals to a compact tile row so
          it reads as a status line above the headline rather than competing
          with it. */}
      <div className="relative z-10 flex-1 flex flex-col lg:hidden px-6 sm:px-10 pt-6 pb-8">
        {/* Reserve the corner the disk occupies so nothing collides with it.
            The compact disk's box is 172px tall and this block starts below the
            container's pt-6, so 156px clears it with room to spare. */}
        <div className="h-[156px] flex-shrink-0" aria-hidden />

        <div className="mt-auto">
          {countdownUnits && (
            <div className="mb-5">
              <p
                className="text-[10px] uppercase tracking-[0.28em] font-semibold mb-2.5"
                style={{ color: "#FFCB05" }}
              >
                {countdownLabel}
              </p>
              <div className="flex items-stretch gap-1.5">
                {countdownUnits.map(({ label, value }) => (
                  <div
                    key={label}
                    className="flex-1 rounded-xl px-1 py-2 text-center"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      border: "1px solid rgba(255,255,255,0.10)",
                      backdropFilter: "blur(8px)",
                      WebkitBackdropFilter: "blur(8px)",
                    }}
                  >
                    <div
                      className="font-mono font-bold text-white leading-none tabular-nums"
                      style={{
                        fontSize: "clamp(1.15rem, 5.5vw, 1.6rem)",
                        textShadow: "0 2px 12px rgba(0,0,0,0.45)",
                      }}
                    >
                      {pad(value)}
                    </div>
                    <div className="text-[9px] uppercase tracking-[0.16em] mt-1.5 text-white/40">
                      {label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {phase === "closed" && (
            <div
              className="flex items-center gap-2.5 mb-5 px-3.5 py-2.5 rounded-xl"
              style={{
                background: "rgba(255,203,5,0.10)",
                border: "1px solid rgba(255,203,5,0.22)",
                backdropFilter: "blur(8px)",
              }}
            >
              <svg className="w-5 h-5 flex-shrink-0" style={{ color: "#FFCB05" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-white font-bold text-sm">Submissions are now closed</span>
            </div>
          )}

          <h1
            className="font-bold text-white tracking-tight leading-[1.05] mb-3"
            style={{ fontSize: "clamp(2rem, 9vw, 3.25rem)" }}
          >
            Every Great Idea{" "}
            <span style={{ color: "#FFCB05" }}>Deserves Its First Pitch</span>
          </h1>

          <p className="text-white/75 text-sm sm:text-base max-w-lg leading-relaxed mb-5">
            From every corner of the Michigan community, ideas become impact. Text it. Say it. Film it. Pitch it.
          </p>

          {/* Side-by-side CTAs */}
          <div className="flex gap-2.5">
            <Link
              href={submitHref}
              className="relative flex-1 flex items-center justify-center gap-1.5 py-3 text-[13px] font-semibold rounded-lg transition-all duration-200 overflow-hidden text-black active:scale-[0.98] group"
              style={{ background: "#FFCB05" }}
            >
              <span className="relative z-10 flex items-center gap-1.5">
                Submit Your Pitch
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </span>
            </Link>

            <Link
              href="/gallery"
              className="flex-1 flex items-center justify-center gap-1.5 py-3 text-[13px] font-semibold rounded-lg transition-all duration-200 active:scale-[0.98]"
              style={{
                border: "1.5px solid rgba(255,255,255,0.25)",
                color: "rgba(255,255,255,0.9)",
                background: "rgba(255,255,255,0.04)",
                backdropFilter: "blur(8px)",
              }}
            >
              View Gallery
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </Link>
          </div>
        </div>
      </div>

      {/* DESKTOP LAYOUT (lg+) */}
      <div className="relative z-10 flex-1 hidden lg:flex items-end px-16 pb-14">
        <div className="max-w-2xl flex-shrink-0">
          <h1
            className="font-bold text-white tracking-tight leading-[1.05] mb-4"
            style={{ fontSize: "clamp(2.5rem, 5vw, 4.5rem)" }}
          >
            Every Great Idea{" "}
            <span style={{ color: "#FFCB05" }}>Deserves Its First Pitch</span>
          </h1>

          <p className="text-white/50 text-lg max-w-lg mb-8 leading-relaxed">
            From every corner of the Michigan community, ideas become impact. Text it. Say it. Film it. Pitch it.
          </p>

          <div className="flex flex-wrap gap-4">
            <Link
              href={submitHref}
              className="relative inline-flex items-center gap-2 px-8 py-4 text-sm font-semibold rounded-xl transition-all duration-200 overflow-hidden text-black hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 group"
              style={{ background: "#FFCB05" }}
            >
              <span className="relative z-10 flex items-center gap-2">
                Submit Your Pitch
                <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </span>
              <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            </Link>

            <Link
              href="/gallery"
              className="inline-flex items-center gap-2 px-8 py-4 text-sm font-semibold rounded-xl transition-all duration-200 group"
              style={{
                border: "2px solid rgba(255,255,255,0.2)",
                color: "rgba(255,255,255,0.85)",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = "#FFCB05";
                e.currentTarget.style.color = "#FFCB05";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = "rgba(255,255,255,0.2)";
                e.currentTarget.style.color = "rgba(255,255,255,0.85)";
              }}
            >
              View Gallery
              <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </Link>
          </div>
        </div>

        <div className="flex-1 flex justify-end items-end">
          {countdownUnits && (
            <div className="text-right">
              <p
                className="text-sm uppercase tracking-[0.25em] mb-5 font-semibold"
                style={{ color: "#FFCB05" }}
              >
                {countdownLabel}
              </p>
              <div className="flex items-center justify-end gap-5">
                {countdownUnits.map(({ label, value }, i) => (
                  <div key={label} className="flex items-center gap-5">
                    <div className="text-center">
                      <div
                        className="font-mono font-bold leading-none"
                        style={{
                          fontSize: "clamp(3rem, 8vw, 6.5rem)",
                          color: "#FFFFFF",
                          textShadow: "0 0 40px rgba(255,203,5,0.15), 0 4px 20px rgba(0,0,0,0.4)",
                        }}
                      >
                        {pad(value)}
                      </div>
                      <div
                        className="text-xs uppercase tracking-[0.2em] mt-2"
                        style={{ color: "rgba(255,255,255,0.35)" }}
                      >
                        {label}
                      </div>
                    </div>
                    {i < 3 && (
                      <div className="flex flex-col items-center gap-3 mb-5">
                        <div className="rounded-full" style={{ width: "8px", height: "8px", background: "#FFCB05", opacity: 0.7 }} />
                        <div className="rounded-full" style={{ width: "8px", height: "8px", background: "#FFCB05", opacity: 0.7 }} />
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <div className="mt-6 flex items-center gap-3 justify-end">
                <div style={{ width: "20px", height: "3px", background: "rgba(255,203,5,0.3)", borderRadius: "2px" }} />
                <div style={{ width: "60px", height: "3px", background: "#FFCB05", borderRadius: "2px" }} />
              </div>
            </div>
          )}

          {phase === "closed" && (
            <div
              className="inline-flex items-center gap-4 px-8 py-5 rounded-2xl"
              style={{
                background: "rgba(255, 203, 5, 0.12)",
                border: "1px solid rgba(255, 203, 5, 0.25)",
                backdropFilter: "blur(12px)",
              }}
            >
              <svg className="w-8 h-8" style={{ color: "#FFCB05" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-white font-bold text-lg tracking-wide">Submissions are now closed</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
