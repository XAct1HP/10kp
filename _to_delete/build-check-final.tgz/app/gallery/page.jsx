"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "../../lib/AuthContext";
import MuxPlayer from "@mux/mux-player-react";
import PageBackground from "../../components/PageBackground";
import galleryHero from "../../public/gallery_hero.png";

const GALLERY_PAGE_SIZE = 200;
const CARDS_PER_PAGE = 36; // 6 cols x 6 rows on desktop; wraps naturally on smaller screens
const TOP_COUNT = 3;

const RANK_BADGES = [
  { label: "1ST PLACE", short: "1ST", gradient: "linear-gradient(135deg, #FFCB05 0%, #FFD876 50%, #FFCB05 100%)", shadow: "0 0 28px rgba(255,203,5,0.6)", textColor: "#0B1A3B", ring: "rgba(255,203,5,0.4)" },
  { label: "2ND PLACE", short: "2ND", gradient: "linear-gradient(135deg, #C0C0C0 0%, #E8E8E8 50%, #A8A8A8 100%)", shadow: "0 0 20px rgba(192,192,192,0.35)", textColor: "#1a1a2e", ring: "rgba(192,192,192,0.3)" },
  { label: "3RD PLACE", short: "3RD", gradient: "linear-gradient(135deg, #CD7F32 0%, #E8A84C 50%, #CD7F32 100%)", shadow: "0 0 18px rgba(205,127,50,0.35)", textColor: "#1a1a2e", ring: "rgba(205,127,50,0.3)" },
];

// Dual-lane gallery: the same grid system renders either the live cohort or
// the archived winners, with the accent palette swapping to signal the switch.
const GALLERY_LANES = {
  current: {
    id: "current",
    label: "Current Cohort",
    accent: "#FFCB05",
    accentSoft: "rgba(255,203,5,0.14)",
    accentBorder: "rgba(255,203,5,0.4)",
    accentOnText: "#0B1A3B",
    ringClass: "ring-[#FFCB05]",
    searchPlaceholder: "Search this year's pitches by title, submitter, or tag",
    emptyCopy: "No pitches submitted yet. Be the first!",
  },
  winners: {
    id: "winners",
    label: "Last Year Winners",
    accent: "#E8A84C",
    accentSoft: "rgba(232,168,76,0.14)",
    accentBorder: "rgba(232,168,76,0.42)",
    accentOnText: "#1a1a2e",
    ringClass: "ring-[#E8A84C]",
    searchPlaceholder: "Search past winners by title, founder, or tag",
    emptyCopy: "No archived winners yet.",
  },
};

// Competition year a seed pitch placed in. Rows created before the
// winner-metadata migration have no winner_year, so fall back to the upload
// date rather than dropping them out of the archive entirely.
function winnerYearOf(pitch) {
  const explicit = Number(pitch.winner_year);
  if (Number.isFinite(explicit)) return explicit;
  const uploaded = pitch.created_at ? new Date(pitch.created_at).getFullYear() : NaN;
  return Number.isFinite(uploaded) ? uploaded : null;
}

// Within a year: award sort_order asc, then title. Unawarded winners sink to
// the end. Vote counts are not consulted — voting is closed on seeds.
function byWinnerAward(a, b) {
  const orderA = Number(a.winner_award?.sort_order);
  const orderB = Number(b.winner_award?.sort_order);
  const hasA = Number.isFinite(orderA);
  const hasB = Number.isFinite(orderB);
  if (hasA && hasB && orderA !== orderB) return orderA - orderB;
  if (hasA !== hasB) return hasA ? -1 : 1;
  return String(a.title || "").localeCompare(String(b.title || ""));
}

export default function GalleryPage() {
  const { user } = useAuth();

  const [allSubmissions, setAllSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [galleryPage, setGalleryPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTagIds, setSelectedTagIds] = useState([]);
  const [tagFilterOpen, setTagFilterOpen] = useState(false);
  const tagFilterRef = useRef(null);

  // Close tag dropdown on outside click / Escape
  useEffect(() => {
    if (!tagFilterOpen) return;
    const handleClick = (e) => {
      if (tagFilterRef.current && !tagFilterRef.current.contains(e.target)) {
        setTagFilterOpen(false);
      }
    };
    const handleKey = (e) => {
      if (e.key === "Escape") setTagFilterOpen(false);
    };
    document.addEventListener("mousedown", handleClick);
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("mousedown", handleClick);
      document.removeEventListener("keydown", handleKey);
    };
  }, [tagFilterOpen]);

  const [voting, setVoting] = useState({ maxVotesPerUser: 5, userVoteCount: 0, remainingVotes: 5 });
  const [voteSubmitting, setVoteSubmitting] = useState({});
  const [selectedPitch, setSelectedPitch] = useState(null);
  const [extractedText, setExtractedText] = useState(null);
  const [extractingText, setExtractingText] = useState(false);

  const [voterProfile, setVoterProfile] = useState({ name: "", email: "" });
  const [showVoterModal, setShowVoterModal] = useState(false);
  const [pendingPitchId, setPendingPitchId] = useState(null);
  const [voterForm, setVoterForm] = useState({ name: "", email: "" });

  const [defaultThumbnails, setDefaultThumbnails] = useState({ audioThumbnail: null, textThumbnail: null });
  const [podiumVisible, setPodiumVisible] = useState(true);
  const [galleryLane, setGalleryLane] = useState("current");
  const [activeWinnerYear, setActiveWinnerYear] = useState(null);

  const [pulsingVoteIds, setPulsingVoteIds] = useState([]);
  const previousVotesRef = useRef({});

  const [hoveredPitchId, setHoveredPitchId] = useState(null);
  const [linkCopied, setLinkCopied] = useState(false);

  const [shuffleSeed] = useState(() => Math.random());

  // ── Auto-fill voter from auth ──
  useEffect(() => {
    if (user?.email) {
      setVoterProfile({ name: user.email.split("@")[0], email: user.email.toLowerCase() });
    } else if (typeof window !== "undefined") {
      try {
        const saved = JSON.parse(localStorage.getItem("gallery_voter_profile") || "null");
        if (saved?.name && saved?.email) setVoterProfile({ name: saved.name, email: saved.email.toLowerCase() });
      } catch {}
    }
  }, [user]);

  // ── Fetch submissions (loops through all pages so tag filter sees every pitch) ──
  const fetchSubmissions = async () => {
    try {
      const collected = [];
      let page = 1;
      let voting = null;
      let defaults = null;
      let display = null;
      // Safety cap: 50 pages × GALLERY_PAGE_SIZE = 10k pitches, plenty of headroom.
      const MAX_PAGES = 50;

      while (page <= MAX_PAGES) {
        const params = new URLSearchParams({
          page: String(page),
          pageSize: String(GALLERY_PAGE_SIZE),
        });
        if (voterProfile.email) params.set("voterEmail", voterProfile.email);
        const res = await fetch(`/api/gallery/submissions?${params}`, { cache: "no-store" });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to load");

        collected.push(...(data.submissions || []));
        if (page === 1) {
          voting = data.voting;
          defaults = data.defaults;
          display = data.display;
        }

        if (!data.pagination?.hasMore) break;
        page += 1;
      }

      setAllSubmissions(collected);
      setVoting(voting || { maxVotesPerUser: 5, userVoteCount: 0, remainingVotes: 5 });
      if (defaults) setDefaultThumbnails(defaults);
      // Admin can toggle the Top 3 podium on/off from the Pitches tab.
      // Missing/undefined defaults to visible so this endpoint stays
      // backwards compatible before the migration lands.
      setPodiumVisible(display?.podiumVisible !== false);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchSubmissions(); }, [voterProfile.email]);

  // Deep link: /gallery?pitch=<id> opens that submission's modal directly.
  // This is the link carried by the admin pitch CSV export, so it has to work
  // for a pitch in either lane. Runs once after the submissions land — the
  // ref stops a later refetch from reopening a modal the user closed.
  const deepLinkHandledRef = useRef(false);
  useEffect(() => {
    if (deepLinkHandledRef.current) return;
    if (loading || !allSubmissions.length) return;
    if (typeof window === "undefined") return;

    const pitchId = new URLSearchParams(window.location.search).get("pitch");
    if (!pitchId) {
      deepLinkHandledRef.current = true;
      return;
    }

    const match = allSubmissions.find((p) => p.id === pitchId);
    deepLinkHandledRef.current = true;
    if (!match) {
      setError("That submission could not be found — it may have been removed.");
      return;
    }
    // Archived winners live in the other lane; switch so closing the modal
    // leaves the user looking at the grid the pitch actually belongs to.
    setGalleryLane(match.is_seed ? "winners" : "current");
    setSelectedPitch(match);
  }, [loading, allSubmissions]);

  // Extract text from document files when a pitch is selected
  useEffect(() => {
    setExtractedText(null);
    setExtractingText(false);
    if (!selectedPitch?.file_path) return;
    if (!/\.(pdf|doc|docx|txt)$/i.test(selectedPitch.file_name || "")) return;
    setExtractingText(true);
    fetch(`/api/gallery/extract-text?path=${encodeURIComponent(selectedPitch.file_path)}&name=${encodeURIComponent(selectedPitch.file_name || "")}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.text) setExtractedText(d.text);
        else if (d.error) console.error("extract-text API error:", d.error);
      })
      .catch((err) => console.error("extract-text fetch error:", err))
      .finally(() => setExtractingText(false));
  }, [selectedPitch?.id]);

  useEffect(() => {
    if (loading) return;
    const id = setInterval(fetchSubmissions, 15000);
    return () => clearInterval(id);
  }, [loading, voterProfile.email]);

  // Pulse animation on vote changes
  useEffect(() => {
    if (!allSubmissions.length) return;
    const changed = allSubmissions.filter((p) => {
      const prev = previousVotesRef.current[p.id];
      return prev !== undefined && prev !== (p.vote_count || 0);
    }).map((p) => p.id);
    previousVotesRef.current = Object.fromEntries(allSubmissions.map((p) => [p.id, p.vote_count || 0]));
    if (!changed.length) return;
    setPulsingVoteIds(changed);
    const t = setTimeout(() => setPulsingVoteIds([]), 1600);
    return () => clearTimeout(t);
  }, [allSubmissions]);

  useEffect(() => {
    if (!selectedPitch) return;
    const updated = allSubmissions.find((p) => p.id === selectedPitch.id);
    if (updated) setSelectedPitch(updated);
  }, [allSubmissions]);

  // ── Lane datasets: live cohort vs archived winners (seed pitches) ──
  const currentCohort = useMemo(
    () => allSubmissions.filter((p) => !p.is_seed),
    [allSubmissions]
  );

  const winnerArchiveByYear = useMemo(() => {
    const grouped = new Map();
    for (const pitch of allSubmissions) {
      if (!pitch.is_seed) continue;
      // winner_year is the competition the pitch placed in; created_at is
      // merely when an admin uploaded it, so it's only a fallback for rows
      // predating the winner-metadata migration.
      const key = winnerYearOf(pitch) ?? "unknown";
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key).push(pitch);
    }
    grouped.forEach((items) => items.sort(byWinnerAward));
    return grouped;
  }, [allSubmissions]);

  const winnerArchiveYears = useMemo(
    () =>
      Array.from(winnerArchiveByYear.keys())
        .filter((k) => k !== "unknown")
        .map(Number)
        .sort((a, b) => b - a),
    [winnerArchiveByYear]
  );

  // Prefer literally "last year"; fall back to the newest archive we have.
  const defaultWinnerYear = useMemo(() => {
    const lastYear = new Date().getFullYear() - 1;
    if (winnerArchiveYears.includes(lastYear)) return lastYear;
    return winnerArchiveYears[0] ?? null;
  }, [winnerArchiveYears]);

  const selectedWinnerYear = activeWinnerYear ?? defaultWinnerYear;

  const winnersCohort = useMemo(() => {
    if (selectedWinnerYear !== null) {
      return winnerArchiveByYear.get(selectedWinnerYear) || [];
    }
    return winnerArchiveByYear.get("unknown") || [];
  }, [winnerArchiveByYear, selectedWinnerYear]);

  const hasWinnersLane = useMemo(
    () => Array.from(winnerArchiveByYear.values()).some((items) => items.length > 0),
    [winnerArchiveByYear]
  );

  const isWinnersLane = galleryLane === "winners";
  const lane = GALLERY_LANES[isWinnersLane ? "winners" : "current"];
  const laneSubmissions = isWinnersLane ? winnersCohort : currentCohort;

  // The winners lane disappears if the archive empties out mid-session.
  useEffect(() => {
    if (isWinnersLane && !hasWinnersLane) setGalleryLane("current");
  }, [isWinnersLane, hasWinnersLane]);

  // ── Unique tag pool derived from the active lane ──
  const availableTags = useMemo(() => {
    const seen = new Map();
    for (const pitch of laneSubmissions) {
      for (const tag of pitch.tags || []) {
        if (tag?.id && !seen.has(tag.id)) {
          seen.set(tag.id, { id: tag.id, name: tag.name || "" });
        }
      }
    }
    return Array.from(seen.values()).sort((a, b) =>
      a.name.localeCompare(b.name)
    );
  }, [laneSubmissions]);

  const filteredSubmissions = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const tagSet = new Set(selectedTagIds);
    const hasQuery = query.length > 0;
    const hasTagFilter = tagSet.size > 0;
    if (!hasQuery && !hasTagFilter) return laneSubmissions;

    return laneSubmissions.filter((pitch) => {
      const pitchTagIds = (pitch.tags || []).map((t) => t?.id).filter(Boolean);

      // Tag filter: OR — pitch matches if it has ANY of the selected tags
      if (hasTagFilter && !pitchTagIds.some((id) => tagSet.has(id))) {
        return false;
      }

      if (!hasQuery) return true;

      const title = (pitch.title || "").toLowerCase();
      const name = (pitch.name || "").toLowerCase();
      const description = (pitch.description || "").toLowerCase();
      const textContent = (pitch.text_content || "").toLowerCase();
      const fileName = (pitch.file_name || "").toLowerCase();
      const tags = (pitch.tags || [])
        .map((tag) => (tag?.name || "").toLowerCase())
        .join(" ");

      return (
        title.includes(query) ||
        name.includes(query) ||
        description.includes(query) ||
        textContent.includes(query) ||
        fileName.includes(query) ||
        tags.includes(query)
      );
    });
  }, [laneSubmissions, searchQuery, selectedTagIds]);

  const toggleTag = (tagId) => {
    setSelectedTagIds((prev) =>
      prev.includes(tagId) ? prev.filter((id) => id !== tagId) : [...prev, tagId]
    );
  };

  useEffect(() => {
    setGalleryPage(1);
  }, [searchQuery, selectedTagIds]);

  // Switching lanes resets paging and tag chips (tag ids rarely overlap between
  // cohorts), but keeps the search query so the same term can be compared.
  const switchLane = (nextLane) => {
    if (nextLane === galleryLane) return;
    setGalleryLane(nextLane);
    setSelectedTagIds([]);
    setTagFilterOpen(false);
    setGalleryPage(1);
  };

  // ── Podium: live top 3 of the current cohort only. The winners lane keeps
  // the plain grid so both lanes share one layout; award category there is
  // carried by the chip on each card instead of a separate hero treatment. ──
  const topPitches = useMemo(
    () =>
      [...currentCohort]
        .sort((a, b) => (b.vote_count || 0) - (a.vote_count || 0))
        .slice(0, TOP_COUNT),
    [currentCohort]
  );

  const podiumPitches = topPitches;
  const showPodium = !isWinnersLane && podiumVisible && podiumPitches.length > 0;

  // ── Gallery ordering: shuffled for the live cohort so nobody gets a
  // permanent front-row seat; award sort_order in the winners lane. ──
  const orderedGallery = useMemo(() => {
    if (isWinnersLane) {
      return [...filteredSubmissions].sort(byWinnerAward);
    }
    const arr = [...filteredSubmissions];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor((shuffleSeed * (i + 1) * 9301 + 49297) % arr.length);
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }, [filteredSubmissions, shuffleSeed, isWinnersLane]);

  const totalGalleryPages = Math.max(1, Math.ceil(orderedGallery.length / CARDS_PER_PAGE));
  const paginatedGallery = orderedGallery.slice((galleryPage - 1) * CARDS_PER_PAGE, galleryPage * CARDS_PER_PAGE);

  // ── Helpers ──
  // Audio submissions are Mux-backed too (Mux is what generates their
  // transcript), so a playback id no longer implies "video". file_type is set
  // at upload time and is the source of truth; the filename is only a fallback
  // for pre-Mux audio uploads.
  const getPitchType = (p) => {
    if (p.file_type === "audio") return "audio";
    if (p.file_type === "video") return "video";
    if (/\.(mp3|wav|ogg|aac|m4a|webm)$/i.test(p.file_name || "")) return "audio";
    if (p.mux_playback_id) return "video";
    return "text";
  };

  // A tile is showing a Mux-rendered frame — which keeps the source video's own
  // aspect ratio — only when no custom thumbnail was uploaded over it. Those get
  // letterboxed rather than cropped, so hover can't rescale the picture.
  const usesMuxFrame = (pitch) =>
    !pitch?.thumbnail_path &&
    Boolean(pitch?.mux_playback_id) &&
    getPitchType(pitch) === "video";

  const getThumbnail = (pitch) => {
    if (pitch.thumbnail_path) return pitch.thumbnail_path;
    const type = getPitchType(pitch);
    // Height only: Mux derives the width and keeps the source framing, so a
    // phone-shot vertical clip stays vertical instead of being smartcropped
    // into the middle of someone's face.
    if (type === "video" && pitch.mux_playback_id) {
      return `https://image.mux.com/${pitch.mux_playback_id}/thumbnail.jpg?time=1&height=360`;
    }
    // Audio-only Mux assets carry no video track, so image.mux.com has nothing
    // to render — they fall through to the admin-configured audio placeholder.
    if (type === "audio") return defaultThumbnails.audioThumbnail || "/placeholder.png";
    if (pitch.text_content || /\.(txt|pdf|doc|docx)$/i.test(pitch.file_name || "")) return defaultThumbnails.textThumbnail || "/placeholder.png";
    return "/placeholder.png";
  };

  const getAnimatedThumbnail = (pitch) => {
    if (!pitch?.mux_playback_id) return null;
    if (getPitchType(pitch) !== "video") return null;
    // Height only, again: passing width AND height makes Mux stretch a vertical
    // clip to fill a 16:9 box, which is what made hover previews look squished.
    // Mux caps animated GIFs at 640px per side, so 360 tall is safe in any
    // orientation.
    return `https://image.mux.com/${pitch.mux_playback_id}/animated.gif?height=360&fps=15`;
  };

  // ── Voting ──
  const submitVoteRequest = async (pitchId, profile) => {
    const target = allSubmissions.find((p) => p.id === pitchId);
    const isUnvote = Boolean(target?.user_has_voted);
    setVoteSubmitting((prev) => ({ ...prev, [pitchId]: true }));
    setError("");
    try {
      const res = await fetch("/api/gallery/votes", {
        method: isUnvote ? "DELETE" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pitchId, voterName: profile.name, voterEmail: profile.email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to cast vote.");
      setAllSubmissions((prev) => prev.map((p) => p.id === pitchId ? { ...p, vote_count: data.pitchVoteCount, user_has_voted: data.action === "voted" } : p));
      setVoting({ maxVotesPerUser: data.maxVotesPerUser, userVoteCount: data.userVoteCount, remainingVotes: data.remainingVotes });
    } catch (err) {
      setError(err.message);
    } finally {
      setVoteSubmitting((prev) => ({ ...prev, [pitchId]: false }));
    }
  };

  const handleVote = async (pitchId) => {
    // The UI hides the vote button on past winners; this backs that up so a
    // stale render can't open the voter modal for one. The API rejects them
    // too — see the is_seed guard in /api/gallery/votes.
    if (allSubmissions.find((p) => p.id === pitchId)?.is_seed) return;
    if (!voterProfile.email || !voterProfile.name) {
      setPendingPitchId(pitchId);
      setVoterForm({ name: "", email: "" });
      setShowVoterModal(true);
      return;
    }
    await submitVoteRequest(pitchId, voterProfile);
  };

  const handleSaveVoterProfile = async (e) => {
    e.preventDefault();
    const name = voterForm.name.trim();
    const email = voterForm.email.trim().toLowerCase();
    if (!name) { setError("Please enter your name."); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setError("Please enter a valid email."); return; }
    const profile = { name, email };
    setVoterProfile(profile);
    if (typeof window !== "undefined") localStorage.setItem("gallery_voter_profile", JSON.stringify(profile));
    setShowVoterModal(false);
    if (pendingPitchId) {
      const pid = pendingPitchId;
      setPendingPitchId(null);
      await submitVoteRequest(pid, profile);
    }
  };

  // ── Share link ──
  // The gallery already opens ?pitch=<id> straight into the modal (that's the
  // link the admin CSV export carries), so a shareable address for a pitch is
  // just the address of the modal the visitor is looking at. Professors ask
  // students to hand in a link to their pitch, so it has to be one click.
  const pitchShareUrl = (pitch) => {
    if (!pitch?.id || typeof window === "undefined") return "";
    return `${window.location.origin}/gallery?pitch=${encodeURIComponent(pitch.id)}`;
  };

  const handleCopyPitchLink = async (pitch) => {
    const url = pitchShareUrl(pitch);
    if (!url) return;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(url);
      } else {
        // No async clipboard on insecure origins or older mobile browsers.
        const scratch = document.createElement("textarea");
        scratch.value = url;
        scratch.setAttribute("readonly", "");
        scratch.style.position = "fixed";
        scratch.style.top = "-1000px";
        scratch.style.opacity = "0";
        document.body.appendChild(scratch);
        scratch.select();
        document.execCommand("copy");
        document.body.removeChild(scratch);
      }
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    } catch {
      setError("Couldn't copy the link automatically — it's in the address bar once you open this pitch.");
    }
  };

  // A newly opened pitch starts with the button back in its resting state.
  useEffect(() => { setLinkCopied(false); }, [selectedPitch?.id]);

  // ═══════════════════════════════════════════════
  //  RENDER
  // ═══════════════════════════════════════════════
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shimmer {
          0% { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
        @keyframes heroFloat {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 0.7; }
        }
        /* The gallery is the one surface that still drew a visible scrollbar.
           Hidden to match the rest of the site — the content still scrolls. */
        .gallery-scroll::-webkit-scrollbar { display: none; }
        .gallery-scroll { scrollbar-width: none; -ms-overflow-style: none; }
      ` }} />

      <div className="h-[calc(100vh-5rem)] overflow-y-auto flex flex-col gallery-scroll"
        style={{ background: "#060810" }}>

        {/* Navbar separator — maize gradient line */}
        <div className="h-px w-full flex-shrink-0"
          style={{ background: "linear-gradient(90deg, transparent, rgba(255,203,5,0.25) 30%, rgba(255,203,5,0.4) 50%, rgba(255,203,5,0.25) 70%, transparent)" }} />

        {/* ═══════════════════════════════════════
             HERO — background image, landing-page style
            ═══════════════════════════════════════ */}
        <div className="relative flex-shrink-0 overflow-hidden"
          style={{ height: "clamp(130px, 18vh, 190px)" }}>
          <PageBackground src={galleryHero} priority quality={68} />
          {/* Gradient overlay matching landing page */}
          <div className="absolute inset-0"
            style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.25) 40%, rgba(6,8,16,0.85) 85%, rgba(6,8,16,1) 100%)" }} />
          {/* Ambient maize glow */}
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[900px] h-[200px] pointer-events-none"
            style={{ background: "radial-gradient(ellipse, rgba(255,203,5,0.06) 0%, transparent 70%)", animation: "heroFloat 6s ease-in-out infinite" }} />

          {/* Hero content */}
          <div className="absolute inset-0 flex items-start justify-between gap-3 px-4 sm:px-10 lg:px-14 pt-5 sm:pt-6">
            {/* Left: label + title stacked */}
            <div className="min-w-0 flex-1">
              <p className="text-[10px] sm:text-xs uppercase tracking-[0.3em] font-semibold mb-1.5"
                style={{ color: "#FFCB05" }}>
                10K Pitches Competition
              </p>
              <h1 className="font-black text-white tracking-tight leading-[1.05]"
                style={{ fontSize: "clamp(1.8rem, 3.5vw, 3rem)" }}>
                The <span style={{ color: "#FFCB05" }}>Pitch</span> Gallery
              </h1>
            </div>
            {/* Right: votes */}
            <div className="flex-shrink-0 pt-0.5">
              {voterProfile.email ? (
                <div className="flex items-center gap-1.5 sm:gap-2.5 rounded-full px-2.5 sm:px-4 py-1 sm:py-1.5"
                  style={{ background: "rgba(255,203,5,0.08)", border: "1px solid rgba(255,203,5,0.15)", backdropFilter: "blur(12px)" }}>
                  <svg className="w-3.5 h-3.5 sm:w-4 sm:h-4" fill="#FFCB05" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" /></svg>
                  <span className="text-xs sm:text-sm font-black" style={{ color: "#FFCB05" }}>{voting.remainingVotes}</span>
                  <span className="hidden sm:inline text-[11px] text-white/30">votes left</span>
                </div>
              ) : null}
            </div>
            </div>
          </div>

        {/* Loading */}
        {loading && (
          <div className="flex-1 flex items-center justify-center">
            <div className="flex flex-col items-center gap-3">
              <svg className="animate-spin h-8 w-8 text-[#FFCB05]" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
              <span className="text-sm text-white/20">Loading pitches...</span>
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="mx-6 sm:mx-10 mt-2 rounded-xl p-3 text-sm flex-shrink-0"
            style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)", color: "#fca5a5" }}>
            {error}
            <button onClick={() => setError("")} className="ml-3 text-red-400/50 hover:text-red-300 text-lg leading-none">&times;</button>
          </div>
        )}

        {/* ═══ DUAL-LANE TOGGLE — lives outside the results block so an
             empty lane can always be switched away from ═══ */}
        {!loading && !error && allSubmissions.length > 0 && hasWinnersLane && (
          <div className="flex-shrink-0 px-3 sm:px-8 lg:px-10 pt-4">
            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              <div
                className="inline-flex items-center gap-1 rounded-full p-1"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
                role="tablist"
                aria-label="Gallery lane"
              >
                {["current", "winners"].map((laneId) => {
                  const config = GALLERY_LANES[laneId];
                  const active = galleryLane === laneId;
                  const count = laneId === "winners" ? winnersCohort.length : currentCohort.length;
                  return (
                    <button
                      key={laneId}
                      type="button"
                      role="tab"
                      aria-selected={active}
                      onClick={() => switchLane(laneId)}
                      className="flex items-center gap-1.5 rounded-full px-3 sm:px-4 py-1.5 text-xs sm:text-[13px] font-bold transition-all duration-200"
                      style={{
                        background: active ? config.accent : "transparent",
                        color: active ? config.accentOnText : "rgba(255,255,255,0.5)",
                      }}
                    >
                      {laneId === "winners" && (
                        <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z" />
                        </svg>
                      )}
                      {config.label}
                      <span
                        className="text-[10px] font-black tabular-nums"
                        style={{ color: active ? config.accentOnText : "rgba(255,255,255,0.3)" }}
                      >
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Year picker — only meaningful with more than one archive year */}
              {isWinnersLane && winnerArchiveYears.length > 1 && (
                <div className="flex items-center gap-1.5 flex-wrap">
                  {winnerArchiveYears.map((year) => {
                    const active = selectedWinnerYear === year;
                    return (
                      <button
                        key={year}
                        type="button"
                        onClick={() => {
                          setActiveWinnerYear(year);
                          setGalleryPage(1);
                        }}
                        className="rounded-full px-2.5 py-1 text-[11px] font-semibold tabular-nums transition-all duration-150"
                        style={{
                          background: active ? lane.accentSoft : "rgba(255,255,255,0.04)",
                          border: `1px solid ${active ? lane.accentBorder : "rgba(255,255,255,0.1)"}`,
                          color: active ? lane.accent : "rgba(255,255,255,0.55)",
                        }}
                      >
                        {year}
                      </button>
                    );
                  })}
                </div>
              )}

              <p className="text-[11px] text-white/35 w-full sm:w-auto">
                {isWinnersLane
                  ? `Final results${selectedWinnerYear ? ` from ${selectedWinnerYear}` : ""} — voting is closed.`
                  : "This year's submissions, open for voting."}
              </p>
            </div>
          </div>
        )}

        {/* Empty state */}
        {!loading && !error && allSubmissions.length === 0 && (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="text-5xl mb-3 opacity-25">🎤</div>
              <p className="text-white/20 text-sm">No pitches submitted yet. Be the first!</p>
            </div>
          </div>
        )}

        {!loading && !error && allSubmissions.length > 0 && laneSubmissions.length === 0 && (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="text-5xl mb-3 opacity-25">{isWinnersLane ? "🏆" : "🎤"}</div>
              <p className="text-white/25 text-sm">{lane.emptyCopy}</p>
            </div>
          </div>
        )}

        {!loading && !error && laneSubmissions.length > 0 && filteredSubmissions.length === 0 && (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="text-5xl mb-3 opacity-25">🔍</div>
              <p className="text-white/30 text-sm">
                {searchQuery && selectedTagIds.length > 0
                  ? `No ${isWinnersLane ? "winners" : "pitches"} match "${searchQuery}" with the selected tags.`
                  : searchQuery
                  ? `No ${isWinnersLane ? "winners" : "pitches"} match "${searchQuery}".`
                  : `No ${isWinnersLane ? "winners" : "pitches"} match the selected tags.`}
              </p>
            </div>
          </div>
        )}

        {/* ═══════════════════════════════════════
             MAIN CONTENT — Top 3 + Grid
            ═══════════════════════════════════════ */}
        {!loading && !error && filteredSubmissions.length > 0 && (
          <div className="flex-1 flex flex-col min-h-0 px-3 sm:px-8 lg:px-10 pt-4">
            {/* ── PODIUM — live top 3 of the current cohort, admin-controlled
                    via the Pitches tab toggle. The winners lane skips it so
                    both lanes share the same uniform grid. ── */}
            {showPodium && (() => {
              const renderPodiumCard = (pitch, actualRank, displayIdx, sizeVariant) => {
                const badge = RANK_BADGES[actualRank];
                const isFirst = actualRank === 0;
                const isPulsing = pulsingVoteIds.includes(pitch.id);
                // sizeVariant: "hero" (mobile 1st), "compact" (mobile 2/3), "desktop-first", "desktop-side"
                const aspect = sizeVariant === "hero" ? "16/9"
                  : sizeVariant === "compact" ? "1/1"
                  : sizeVariant === "desktop-first" ? "16/7.5"
                  : "16/9";
                const titleSize = sizeVariant === "hero" ? "17px"
                  : sizeVariant === "compact" ? "12px"
                  : isFirst ? "16px" : "14px";
                const subtitleSize = sizeVariant === "compact" ? "10px" : "12px";
                const infoPad = sizeVariant === "compact" ? "p-2.5" : "p-4";
                const badgePad = sizeVariant === "compact" ? "pl-1 pr-2 py-0.5" : "pl-1.5 pr-3 py-1";
                const badgeIcon = sizeVariant === "compact" ? "w-4 h-4" : "w-6 h-6";
                const badgeIconSvg = sizeVariant === "compact" ? "w-2.5 h-2.5" : "w-3.5 h-3.5";
                const badgeText = sizeVariant === "compact" ? "text-[9px]" : "text-[11px]";
                const votePad = sizeVariant === "compact" ? "px-2 py-1" : "px-3 py-1.5";
                const voteIcon = sizeVariant === "compact" ? "w-3.5 h-3.5" : "w-5 h-5";
                const voteText = sizeVariant === "compact" ? "text-xs" : "text-base";
                const cornerPos = sizeVariant === "compact" ? "top-1.5" : "top-3";
                const cornerLeft = sizeVariant === "compact" ? "left-1.5" : "left-3";
                const cornerRight = sizeVariant === "compact" ? "right-1.5" : "right-3";

                const animatedSrc = getAnimatedThumbnail(pitch);
                const isHovered = hoveredPitchId === pitch.id;
                // Mux frames keep the source aspect ratio, so they're letterboxed
                // rather than cropped — and the ken-burns hover zoom is dropped
                // for them so swapping in the GIF doesn't also change the scale.
                const muxFrame = usesMuxFrame(pitch);
                const frameFit = muxFrame ? "object-contain" : "object-cover";

                return (
                  <button key={pitch.id}
                    onClick={() => setSelectedPitch(pitch)}
                    onMouseEnter={() => setHoveredPitchId(pitch.id)}
                    onMouseLeave={() => setHoveredPitchId((id) => (id === pitch.id ? null : id))}
                    className={`relative group rounded-2xl overflow-hidden transition-all duration-300 hover:scale-[1.02] w-full ${isPulsing ? `ring-2 ${lane.ringClass}` : ""}`}
                    style={{
                      aspectRatio: aspect,
                      boxShadow: `${badge.shadow}, 0 8px 32px rgba(0,0,0,0.4)`,
                      border: `1px solid ${badge.ring}`,
                      animation: "fadeInUp 0.5s ease-out both",
                      animationDelay: `${displayIdx * 0.12}s`,
                    }}>
                    <img src={getThumbnail(pitch)} alt={pitch.title}
                      className={`absolute inset-0 w-full h-full ${frameFit} transition-transform duration-700 ${muxFrame ? "" : "group-hover:scale-110"}`}
                      style={muxFrame ? { background: "#000" } : undefined} loading="lazy" />
                    {animatedSrc && isHovered && (
                      <img src={animatedSrc} alt=""
                        className={`absolute inset-0 w-full h-full ${frameFit}`}
                        style={{ background: "#000" }} aria-hidden="true" />
                    )}

                    <div className="absolute inset-0"
                      style={{ background: "linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.35) 45%, transparent 75%)" }} />

                    {/* Crown badge */}
                    <div className={`absolute ${cornerPos} ${cornerLeft} flex items-center gap-1.5 rounded-full ${badgePad}`}
                      style={{ background: badge.gradient, boxShadow: badge.shadow }}>
                      <div className={`${badgeIcon} rounded-full flex items-center justify-center`} style={{ background: "rgba(0,0,0,0.2)" }}>
                        <svg className={badgeIconSvg} fill={badge.textColor} viewBox="0 0 24 24">
                          <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z" />
                        </svg>
                      </div>
                      <span className={`${badgeText} font-black tracking-wider`} style={{ color: badge.textColor }}>{badge.short}</span>
                    </div>

                    {/* Past-winner crown, for a seed that slipped into the
                        live top 3 before the winners lane existed. */}
                    {pitch.is_seed && (
                      <div
                        className={`absolute ${sizeVariant === "compact" ? "bottom-1.5 left-1.5" : "bottom-3 left-3"} flex items-center gap-1 rounded-full ${sizeVariant === "compact" ? "pl-1 pr-1.5 py-0.5" : "pl-1.5 pr-2 py-1"}`}
                        style={{
                          background: "rgba(0,0,0,0.55)",
                          backdropFilter: "blur(8px)",
                          border: "1px solid rgba(255,203,5,0.3)",
                        }}
                        title="Past winner"
                      >
                        <svg
                          className={sizeVariant === "compact" ? "w-3 h-3" : "w-3.5 h-3.5"}
                          fill="#FFCB05"
                          viewBox="0 0 24 24"
                        >
                          <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z" />
                        </svg>
                        {sizeVariant !== "compact" && (
                          <span className="text-[9px] font-black uppercase tracking-wider text-white/85">
                            Past
                          </span>
                        )}
                      </div>
                    )}

                    {/* Vote badge */}
                    <div className={`absolute ${cornerPos} ${cornerRight} flex items-center gap-1 rounded-full ${votePad}`}
                      style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(12px)", border: `1px solid ${lane.accentBorder}` }}>
                      <svg className={voteIcon} fill={lane.accent} viewBox="0 0 24 24">
                        <path d="M12 4l2.5 5.1 5.5.8-4 3.9.9 5.5L12 16.8l-4.9 2.5.9-5.5-4-3.9 5.5-.8L12 4z" />
                      </svg>
                      <span className={`${voteText} font-black`} style={{ color: lane.accent }}>{pitch.vote_count || 0}</span>
                    </div>

                    {/* Info */}
                    <div className={`absolute bottom-0 left-0 right-0 ${infoPad}`}>
                      <p className="text-white font-bold truncate leading-tight" style={{ fontSize: titleSize }}>{pitch.title}</p>
                      <p className="text-white/50 truncate mt-0.5" style={{ fontSize: subtitleSize }}>{pitch.name}</p>
                    </div>

                    {pitch.user_has_voted && (
                      <div className={`absolute ${sizeVariant === "compact" ? "bottom-1.5 right-1.5 w-5 h-5" : "bottom-3 right-3 w-7 h-7"} rounded-full flex items-center justify-center`} style={{ background: lane.accent }}>
                        <svg className={sizeVariant === "compact" ? "w-3 h-3" : "w-4 h-4"} fill="none" viewBox="0 0 24 24" stroke="#0B1A3B" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                      </div>
                    )}
                  </button>
                );
              };

              return (
                <div className="flex-shrink-0 mb-4">
                  {/* Mobile podium — 1st hero, 2nd/3rd row below */}
                  <div className="md:hidden space-y-2">
                    {renderPodiumCard(podiumPitches[0], 0, 0, "hero")}
                    {podiumPitches.length > 1 && (
                      <div className="grid grid-cols-2 gap-2">
                        {podiumPitches[1] && renderPodiumCard(podiumPitches[1], 1, 1, "compact")}
                        {podiumPitches[2] && renderPodiumCard(podiumPitches[2], 2, 2, "compact")}
                      </div>
                    )}
                  </div>

                  {/* Desktop podium — 2nd | 1st (larger) | 3rd */}
                  <div className="hidden md:grid gap-3 items-end"
                    style={{ gridTemplateColumns: podiumPitches.length >= 3 ? "1fr 1.2fr 1fr" : `repeat(${podiumPitches.length}, 1fr)` }}>
                    {(podiumPitches.length >= 3 ? [podiumPitches[1], podiumPitches[0], podiumPitches[2]] : podiumPitches).map((pitch, displayIdx) => {
                      const actualRank = podiumPitches.length >= 3 ? [1, 0, 2][displayIdx] : displayIdx;
                      const variant = actualRank === 0 ? "desktop-first" : "desktop-side";
                      return renderPodiumCard(pitch, actualRank, displayIdx, variant);
                    })}
                  </div>
                </div>
              );
            })()}

            {/* Search */}
            <div className="flex-shrink-0 mb-4">
              <div
                className="flex items-center gap-2 rounded-xl px-3 py-2"
                style={{
                  background: "rgba(255,255,255,0.08)",
                  border: "1px solid rgba(255,255,255,0.2)",
                }}
              >
                <svg className="w-4 h-4 text-white/70 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35m1.35-5.65a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={lane.searchPlaceholder}
                  className="w-full bg-transparent text-sm text-white placeholder:text-white/60 focus:outline-none"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="text-white/60 hover:text-white text-lg leading-none px-1 flex-shrink-0"
                    aria-label="Clear search"
                  >
                    &times;
                  </button>
                )}

                {availableTags.length > 0 && (
                  <div ref={tagFilterRef} className="relative flex-shrink-0">
                    <button
                      onClick={() => setTagFilterOpen((v) => !v)}
                      className="flex items-center gap-1.5 text-xs font-medium rounded-lg px-2.5 py-1 transition-all duration-150"
                      style={
                        selectedTagIds.length > 0
                          ? {
                              background: lane.accentSoft,
                              border: `1px solid ${lane.accent}`,
                              color: lane.accent,
                            }
                          : {
                              background: "rgba(255,255,255,0.05)",
                              border: "1px solid rgba(255,255,255,0.2)",
                              color: "rgba(255,255,255,0.8)",
                            }
                      }
                      aria-haspopup="true"
                      aria-expanded={tagFilterOpen}
                    >
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L15 12.414V19a1 1 0 01-.553.894l-4 2A1 1 0 019 21v-8.586L3.293 6.707A1 1 0 013 6V4z" />
                      </svg>
                      <span>Filter</span>
                      {selectedTagIds.length > 0 && (
                        <span
                          className="inline-flex items-center justify-center rounded-full text-[10px] font-bold min-w-[16px] h-4 px-1"
                          style={{ background: lane.accent, color: lane.accentOnText }}
                        >
                          {selectedTagIds.length}
                        </span>
                      )}
                    </button>

                    {tagFilterOpen && (
                      <div
                        className="absolute right-0 top-full mt-2 z-20 rounded-xl p-3 w-64 max-h-80 overflow-y-auto"
                        style={{
                          background: "rgba(11,26,59,0.98)",
                          border: "1px solid rgba(255,255,255,0.15)",
                          boxShadow: "0 12px 32px rgba(0,0,0,0.5)",
                          backdropFilter: "blur(12px)",
                        }}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[11px] uppercase tracking-wider text-white/50">
                            Filter by tag
                          </span>
                          {selectedTagIds.length > 0 && (
                            <button
                              onClick={() => setSelectedTagIds([])}
                              className="text-[11px] text-white/50 hover:text-white transition-colors underline underline-offset-2"
                            >
                              Clear
                            </button>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {availableTags.map((tag) => {
                            const active = selectedTagIds.includes(tag.id);
                            return (
                              <button
                                key={tag.id}
                                onClick={() => toggleTag(tag.id)}
                                className="text-xs font-medium rounded-full px-3 py-1 transition-all duration-150"
                                style={
                                  active
                                    ? {
                                        background: lane.accentSoft,
                                        border: `1px solid ${lane.accent}`,
                                        color: lane.accent,
                                      }
                                    : {
                                        background: "rgba(255,255,255,0.04)",
                                        border: "1px solid rgba(255,255,255,0.15)",
                                        color: "rgba(255,255,255,0.7)",
                                      }
                                }
                              >
                                {tag.name}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
              <p className="text-[11px] text-white/50 mt-1.5">
                Showing {filteredSubmissions.length} of {laneSubmissions.length}{" "}
                {isWinnersLane ? "past winners" : "pitches"}
              </p>
            </div>

            {/* ── ALL PITCHES GRID ── */}
            <div>
              {/* Grid — responsive: 2 cols on phones, 3 on small tablets, 4 on tablets, 6 on desktop */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-0.5 sm:gap-0 rounded-xl overflow-hidden">
                {paginatedGallery.map((pitch, i) => {
                  const isPulsing = pulsingVoteIds.includes(pitch.id);
                  const animatedSrc = getAnimatedThumbnail(pitch);
                  const isHovered = hoveredPitchId === pitch.id;
                  const muxFrame = usesMuxFrame(pitch);
                  const frameFit = muxFrame ? "object-contain" : "object-cover";
                  const awardName = isWinnersLane
                    ? (pitch.winner_award?.name || "").trim()
                    : "";

                  return (
                    <button key={pitch.id}
                      onClick={() => setSelectedPitch(pitch)}
                      onMouseEnter={() => setHoveredPitchId(pitch.id)}
                      onMouseLeave={() => setHoveredPitchId((id) => (id === pitch.id ? null : id))}
                      className={`relative block w-full overflow-hidden bg-[#0a0e18] group ${isPulsing ? `ring-2 ring-inset ${lane.ringClass}` : ""}`}
                      style={{
                        aspectRatio: "16/9",
                        animation: "fadeInUp 0.3s ease-out both",
                        animationDelay: `${i * 0.025}s`,
                      }}>
                      <img src={getThumbnail(pitch)} alt={pitch.title}
                        className={`w-full h-full ${frameFit} transition-transform duration-500 ${muxFrame ? "" : "group-hover:scale-110"}`}
                        style={muxFrame ? { background: "#000" } : undefined} loading="lazy" />
                      {animatedSrc && isHovered && (
                        <img src={animatedSrc} alt=""
                          className={`absolute inset-0 w-full h-full ${frameFit}`}
                          style={{ background: "#000" }} aria-hidden="true" />
                      )}

                      {/* Hover overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-2.5">
                        <p className="text-white font-bold text-[11px] truncate leading-tight">{pitch.title}</p>
                        <p className="text-white/50 text-[10px] truncate">{pitch.name}</p>
                      </div>

                      {/* Vote tally — live cohort only. Winners can't be voted
                          on, so a permanent zero would just read as broken. */}
                      {!isWinnersLane && (
                        <div className="absolute top-1.5 right-1.5 flex items-center gap-1 rounded-full px-2 py-0.5"
                          style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(8px)" }}>
                          <svg className="w-3.5 h-3.5" fill={lane.accent} viewBox="0 0 24 24">
                            <path d="M12 4l2.5 5.1 5.5.8-4 3.9.9 5.5L12 16.8l-4.9 2.5.9-5.5-4-3.9 5.5-.8L12 4z" />
                          </svg>
                          <span className="text-[11px] font-bold text-white">{pitch.vote_count || 0}</span>
                        </div>
                      )}

                      {/* Top-left marker: award category in the winners lane,
                          past-winner crown when a seed is mixed into cohort. */}
                      {isWinnersLane ? (
                        <div
                          className="absolute top-1.5 left-1.5 max-w-[75%] truncate rounded-full px-1.5 py-0.5 text-[9px] font-black tracking-wider"
                          style={{
                            background: "rgba(0,0,0,0.55)",
                            backdropFilter: "blur(8px)",
                            border: `1px solid ${lane.accentBorder}`,
                            color: lane.accent,
                          }}
                          title={awardName || "Winner"}
                        >
                          {awardName || "Winner"}
                        </div>
                      ) : (
                        pitch.is_seed && (
                          <div
                            className="absolute top-1.5 left-1.5 w-5 h-5 rounded-full flex items-center justify-center"
                            style={{
                              background: "rgba(0,0,0,0.55)",
                              backdropFilter: "blur(8px)",
                              border: "1px solid rgba(255,203,5,0.35)",
                            }}
                            title="Past winner"
                          >
                            <svg className="w-3 h-3" fill="#FFCB05" viewBox="0 0 24 24">
                              <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z" />
                            </svg>
                          </div>
                        )
                      )}

                      {/* Voted */}
                      {pitch.user_has_voted && !isWinnersLane && (
                        <div className="absolute bottom-1.5 right-1.5 w-5 h-5 rounded-full flex items-center justify-center" style={{ background: lane.accent }}>
                          <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="#0B1A3B" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Pagination — always visible under last row, disabled when only 1 page */}
              <div className="flex items-center justify-center py-5">
                <div className={`flex items-center gap-1 rounded-full px-3 py-1.5 transition-opacity ${totalGalleryPages <= 1 ? "opacity-30 pointer-events-none" : ""}`}
                  style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                  <button onClick={() => { setGalleryPage((p) => Math.max(1, p - 1)); window.scrollTo({ top: 0, behavior: "smooth" }); }} disabled={galleryPage <= 1}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white/25 hover:text-white hover:bg-white/5 disabled:opacity-25 disabled:cursor-not-allowed transition-all">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
                  </button>
                  {Array.from({ length: Math.max(Math.min(totalGalleryPages, 9), 1) }, (_, i) => i + 1).map((p) => (
                    <button key={p} onClick={() => { setGalleryPage(p); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                      disabled={totalGalleryPages <= 1}
                      className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all disabled:cursor-not-allowed"
                      style={{
                        background: p === galleryPage ? lane.accent : "transparent",
                        color: p === galleryPage ? lane.accentOnText : "rgba(255,255,255,0.2)",
                      }}>
                      {p}
                    </button>
                  ))}
                  {totalGalleryPages > 9 && <span className="text-white/10 text-[10px] px-1">...</span>}
                  <button onClick={() => { setGalleryPage((p) => Math.min(totalGalleryPages, p + 1)); window.scrollTo({ top: 0, behavior: "smooth" }); }} disabled={galleryPage >= totalGalleryPages}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white/25 hover:text-white hover:bg-white/5 disabled:opacity-25 disabled:cursor-not-allowed transition-all">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ═══ PITCH DETAIL MODAL ═══ */}
        {selectedPitch && (
          <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-0 md:p-6"
            style={{ background: "rgba(0,0,0,0.88)" }}
            onClick={() => setSelectedPitch(null)}>
            {/* Mobile is a bottom sheet pinned to the viewport; desktop keeps the
                centered dialog. `dvh` so mobile browser chrome doesn't clip it. */}
            <div className="relative w-full max-w-6xl h-[92dvh] md:h-auto md:max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
              {/* Floating custom thumbnail — overlaps top-left corner (desktop only; hidden on mobile to avoid clipping) */}
              {(getPitchType(selectedPitch) === "text" || getPitchType(selectedPitch) === "audio") && selectedPitch.thumbnail_path && (
                <img src={selectedPitch.thumbnail_path} alt=""
                  className="hidden md:block absolute z-10 rounded-2xl pointer-events-none"
                  style={{
                    width: "350px",
                    height: "auto",
                    top: "-24px",
                    left: "-24px",
                    boxShadow: "0 12px 40px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.08)",
                  }}
                />
              )}
              <div className="w-full h-full md:h-auto md:max-h-[90vh] flex flex-col rounded-t-3xl md:rounded-2xl overflow-hidden"
              style={{
                background: "linear-gradient(135deg, #0B1A3B 0%, #0d1f45 100%)",
                boxShadow: "0 40px 100px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.06)",
              }}>

              {/* Mobile: grab handle + a close button that never scrolls away.
                  Both are outside the scroll container on purpose. */}
              <div className="md:hidden flex-shrink-0 relative pt-2.5 pb-1">
                <div className="mx-auto w-10 h-1 rounded-full" style={{ background: "rgba(255,255,255,0.18)" }} />
                <button
                  onClick={() => setSelectedPitch(null)}
                  aria-label="Close"
                  className="absolute top-1.5 right-3 p-2 rounded-full text-white/50 active:text-white transition-colors"
                  style={{ background: "rgba(255,255,255,0.06)" }}
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>

              {/* On mobile this wrapper is the single scroll surface, so the
                  media, the title and the description all move as one column
                  instead of fighting over two 45vh scrollers. On desktop it
                  reverts to the side-by-side layout with its own inner scrolls. */}
              <div className="flex-1 min-h-0 flex flex-col md:flex-row overflow-y-auto md:overflow-hidden no-scrollbar">

              {/* Left: Media / Content */}
              <div className="flex-shrink-0 md:flex-1 md:flex-shrink min-w-0 flex items-center justify-center" style={{ background: (getPitchType(selectedPitch) === "text" || getPitchType(selectedPitch) === "audio") ? "#0a0f1e" : "#000" }}>
                <style>{`.text-pitch-scroll::-webkit-scrollbar { display: none; }`}</style>
                {getPitchType(selectedPitch) === "video" && selectedPitch.mux_playback_id ? (
                  // contain, not cover: a portrait phone recording is shown whole
                  // with black margins rather than cropped in on the speaker.
                  <MuxPlayer playbackId={selectedPitch.mux_playback_id} accentColor="#FFCB05"
                    style={{ width: "100%", aspectRatio: "16/9", "--media-object-fit": "contain" }} />
                ) : getPitchType(selectedPitch) === "audio" ? (
                  <div className="w-full flex flex-col md:h-full md:max-h-[80vh]">
                    {/* Audio player */}
                    <div className="w-full px-5 sm:px-8 pt-5 sm:pt-8 pb-4 flex-shrink-0">
                      {/* Reserved space for floating thumbnail — desktop only (thumbnail is hidden on mobile) */}
                      {selectedPitch.thumbnail_path && (
                        <div className="hidden md:block" style={{ float: "left", width: "340px", height: "210px", marginRight: "20px", marginBottom: "4px", marginTop: "-32px", marginLeft: "-32px" }} />
                      )}
                      {/* Mobile inline thumbnail — since the floating one is hidden, show a compact version here */}
                      {selectedPitch.thumbnail_path && (
                        <img
                          src={selectedPitch.thumbnail_path}
                          alt=""
                          className="md:hidden w-full aspect-video rounded-xl object-cover mb-4"
                          style={{ border: "1px solid rgba(255,255,255,0.08)" }}
                        />
                      )}
                      {selectedPitch.mux_playback_id ? (
                        // Mux hosts audio too, and its audio-mode player is the
                        // same playback bar the admin panel uses — plus the
                        // auto-generated captions track.
                        <MuxPlayer
                          playbackId={selectedPitch.mux_playback_id}
                          accentColor="#FFCB05"
                          audio
                          style={{ width: "100%" }}
                        />
                      ) : selectedPitch.file_path ? (
                        <audio controls className="w-full" style={{ filter: "invert(1) hue-rotate(180deg)", opacity: 0.7 }}>
                          <source src={`/api/gallery/stream-audio?path=${encodeURIComponent(selectedPitch.file_path)}`} />
                        </audio>
                      ) : null}
                    </div>
                    {/* Description text below player */}
                    {(extractedText || selectedPitch.text_content) && (
                      <div className="w-full md:flex-1 md:overflow-y-auto text-pitch-scroll px-5 sm:px-8 pb-6 sm:pb-8" style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}>
                        <p className="text-sm text-white/70 leading-relaxed">{extractedText || selectedPitch.text_content}</p>
                      </div>
                    )}
                  </div>
                ) : getPitchType(selectedPitch) === "text" ? (
                  <div className="w-full flex flex-col md:h-full md:max-h-[80vh]">
                    {extractingText ? (
                      <div className="w-full flex-1 flex items-center justify-center">
                        <svg className="animate-spin h-6 w-6 text-white/30" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
                      </div>
                    ) : (extractedText || selectedPitch.text_content) ? (
                      <div className="w-full md:h-full md:overflow-y-auto text-pitch-scroll p-5 sm:p-8 md:max-h-[80vh]" style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}>
                        {/* Desktop: reserve space for the floating thumbnail overlay */}
                        {selectedPitch.thumbnail_path && (
                          <div className="hidden md:block" style={{ float: "left", width: "340px", height: "210px", marginRight: "20px", marginBottom: "4px", marginTop: "-32px", marginLeft: "-32px" }} />
                        )}
                        {/* Mobile: show the thumbnail inline since the floating one is hidden */}
                        {selectedPitch.thumbnail_path && (
                          <img
                            src={selectedPitch.thumbnail_path}
                            alt=""
                            className="md:hidden w-full aspect-video rounded-xl object-cover mb-4"
                            style={{ border: "1px solid rgba(255,255,255,0.08)" }}
                          />
                        )}
                        <p className="text-sm text-white/70 leading-relaxed">{extractedText || selectedPitch.text_content}</p>
                      </div>
                    ) : (
                      <div className="w-full flex items-center justify-center p-8">
                        <p className="text-white/25 text-sm italic">No text content available</p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="w-full" style={{ aspectRatio: "16/9" }}>
                    <img src={getThumbnail(selectedPitch)} alt={selectedPitch.title} className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              {/* Right: Info */}
              <div
                className="w-full md:w-96 md:flex-shrink-0 flex flex-col px-5 pt-5 pb-0 sm:px-6 sm:pt-6 md:pb-6 md:max-h-none md:overflow-visible border-t md:border-t-0 md:border-l"
                style={{ borderColor: "rgba(255,255,255,0.05)" }}
              >
                {/* Desktop close — mobile has its own pinned button in the header. */}
                <button onClick={() => setSelectedPitch(null)}
                  className="hidden md:block self-end p-1.5 rounded-lg text-white/20 hover:text-white hover:bg-white/5 transition-colors mb-3">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>

                {/* Rank badge — live cohort top-3 only when podium is on.
                    Seed pitches show award category below instead. */}
                {!selectedPitch.is_seed && (() => {
                  const rank = podiumVisible
                    ? podiumPitches.findIndex((p) => p.id === selectedPitch.id)
                    : -1;
                  if (rank === -1 || rank >= RANK_BADGES.length) return null;
                  const badge = RANK_BADGES[rank];
                  return (
                    <div className="flex items-center gap-2 mb-3">
                      <div className="flex items-center gap-1.5 rounded-full pl-1.5 pr-3 py-1" style={{ background: badge.gradient, boxShadow: badge.shadow }}>
                        <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: "rgba(0,0,0,0.2)" }}>
                          <svg className="w-3 h-3" fill={badge.textColor} viewBox="0 0 24 24"><path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z" /></svg>
                        </div>
                        <span className="text-[10px] font-black tracking-wider" style={{ color: badge.textColor }}>{badge.label}</span>
                      </div>
                    </div>
                  );
                })()}

                {selectedPitch.is_seed && (
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    {selectedPitch.winner_award?.name && (
                      <div
                        className="inline-flex items-center gap-1.5 rounded-full pl-1.5 pr-3 py-1"
                        style={{
                          background: "linear-gradient(135deg, #CD7F32 0%, #E8A84C 50%, #CD7F32 100%)",
                          boxShadow: "0 0 18px rgba(205,127,50,0.35)",
                        }}
                      >
                        <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: "rgba(0,0,0,0.2)" }}>
                          <svg className="w-3 h-3" fill="#1a1a2e" viewBox="0 0 24 24">
                            <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z" />
                          </svg>
                        </div>
                        <span className="text-[10px] font-black tracking-wider" style={{ color: "#1a1a2e" }}>
                          {selectedPitch.winner_award.name}
                        </span>
                      </div>
                    )}
                    <div
                      className="inline-flex items-center gap-1.5 rounded-full pl-1.5 pr-3 py-1"
                      style={{
                        background: "rgba(255,203,5,0.12)",
                        border: "1px solid rgba(255,203,5,0.35)",
                      }}
                    >
                      <svg className="w-3.5 h-3.5" fill="#FFCB05" viewBox="0 0 24 24">
                        <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z" />
                      </svg>
                      <span className="text-[10px] font-black tracking-wider" style={{ color: "#FFCB05" }}>
                        {winnerYearOf(selectedPitch)
                          ? `${winnerYearOf(selectedPitch)} WINNER`
                          : "PAST WINNER"}
                      </span>
                    </div>
                  </div>
                )}

                <h2 className="text-2xl md:text-xl font-bold text-white leading-tight mb-1">{selectedPitch.title}</h2>
                <p className="text-xs text-white/35 mb-3">by {selectedPitch.name}</p>

                <div className="flex-shrink-0 mb-4">
                  <button
                    type="button"
                    onClick={() => handleCopyPitchLink(selectedPitch)}
                    className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-semibold transition-all duration-150"
                    style={{
                      background: linkCopied ? "rgba(255,203,5,0.14)" : "rgba(255,255,255,0.05)",
                      border: `1px solid ${linkCopied ? "rgba(255,203,5,0.4)" : "rgba(255,255,255,0.12)"}`,
                      color: linkCopied ? "#FFCB05" : "rgba(255,255,255,0.6)",
                    }}
                    aria-label="Copy a shareable link to this pitch"
                  >
                    {linkCopied ? (
                      <>
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                        Link copied
                      </>
                    ) : (
                      <>
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M13.828 10.172a4 4 0 010 5.656l-3 3a4 4 0 01-5.656-5.656l1.5-1.5" />
                          <path strokeLinecap="round" strokeLinejoin="round" d="M10.172 13.828a4 4 0 010-5.656l3-3a4 4 0 015.656 5.656l-1.5 1.5" />
                        </svg>
                        Copy link
                      </>
                    )}
                  </button>
                </div>

                {/* Mobile: flows into the sheet's single scroll. Desktop: its own
                    scroll area so a long description can't push the vote bar off. */}
                <div className="mb-4 md:flex-1 md:min-h-0 md:overflow-y-auto no-scrollbar">
                  <p className="text-sm text-white/45 leading-relaxed whitespace-pre-wrap">{selectedPitch.description}</p>
                </div>

                {selectedPitch.tags?.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mb-4 flex-shrink-0">
                    {selectedPitch.tags.map((tag) => (
                      <span key={tag.id} className="px-2.5 py-0.5 text-[10px] rounded-full font-medium"
                        style={{ background: "rgba(255,203,5,0.08)", color: "rgba(255,203,5,0.6)", border: "1px solid rgba(255,203,5,0.1)" }}>{tag.name}</span>
                    ))}
                  </div>
                )}

                {/* Sheet footer. One sticky container, not several — stacked
                    sticky siblings would pile up on the same bottom edge. */}
                <div
                  className="flex-shrink-0 sticky bottom-0 md:static pb-5 md:pb-0"
                  style={{
                    background: "linear-gradient(to bottom, rgba(13,31,69,0.82) 0%, #0d1f45 45%)",
                    backdropFilter: "blur(12px)",
                    WebkitBackdropFilter: "blur(12px)",
                  }}
                >
                {/* Vote area — archived winners are a showcase, not a ballot,
                    so they get a closed-voting notice instead of a button. */}
                {selectedPitch.is_seed ? (
                  <div
                    className="flex items-center gap-2.5 pt-4"
                    style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}
                  >
                    <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="rgba(255,255,255,0.35)" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                    <p className="text-xs text-white/40">
                      Voting is closed for past winners — this pitch is here as an archive.
                    </p>
                  </div>
                ) : (
                <div
                  className="flex items-center justify-between pt-4"
                  style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}
                >
                  <div className="flex items-center gap-2">
                    <svg className="w-6 h-6" fill="#FFCB05" viewBox="0 0 24 24">
                      <path d="M12 4l2.5 5.1 5.5.8-4 3.9.9 5.5L12 16.8l-4.9 2.5.9-5.5-4-3.9 5.5-.8L12 4z" />
                    </svg>
                    <span className="text-2xl font-black text-white tabular-nums">{selectedPitch.vote_count || 0}</span>
                  </div>
                  <button onClick={() => handleVote(selectedPitch.id)}
                    disabled={voteSubmitting[selectedPitch.id]}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold transition-all disabled:opacity-50"
                    style={{
                      background: selectedPitch.user_has_voted ? "rgba(255,203,5,0.12)" : "#FFCB05",
                      color: selectedPitch.user_has_voted ? "#FFCB05" : "#0B1A3B",
                      border: selectedPitch.user_has_voted ? "1px solid rgba(255,203,5,0.25)" : "1px solid transparent",
                    }}>
                    {voteSubmitting[selectedPitch.id] ? (
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
                    ) : selectedPitch.user_has_voted ? (
                      <>
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                        Voted
                      </>
                    ) : (
                      <>
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 4l2.5 5.1 5.5.8-4 3.9.9 5.5L12 16.8l-4.9 2.5.9-5.5-4-3.9 5.5-.8L12 4z" /></svg>
                        Vote
                      </>
                    )}
                  </button>
                </div>
                )}

                {voterProfile.email && !selectedPitch.is_seed && (
                  <p
                    className="text-[10px] text-white/15 mt-2 text-center"
                  >
                    {voting.remainingVotes} of {voting.maxVotesPerUser} votes remaining
                  </p>
                )}
                </div>
              </div>
              </div>
            </div>
            </div>
          </div>
        )}

        {/* VOTER MODAL */}
        {showVoterModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center px-4"
            style={{ background: "rgba(0,0,0,0.75)" }}
            onClick={() => { setShowVoterModal(false); setPendingPitchId(null); }}>
            <div className="w-full max-w-md rounded-2xl p-6"
              style={{ background: "linear-gradient(135deg, rgba(11,26,59,0.97), rgba(13,21,48,0.97))", backdropFilter: "blur(24px)", border: "1px solid rgba(255,203,5,0.15)", boxShadow: "0 32px 80px rgba(0,0,0,0.6)" }}
              onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center gap-2 mb-1">
                <svg className="w-5 h-5" fill="#FFCB05" viewBox="0 0 24 24"><path d="M12 4l2.5 5.1 5.5.8-4 3.9.9 5.5L12 16.8l-4.9 2.5.9-5.5-4-3.9 5.5-.8L12 4z" /></svg>
                <h3 className="text-lg font-bold text-white">Cast Your Vote</h3>
              </div>
              <p className="text-sm text-white/35 mb-5">Enter your name and email to start voting.</p>
              <form onSubmit={handleSaveVoterProfile} className="space-y-3">
                <input type="text" placeholder="Your name" value={voterForm.name}
                  onChange={(e) => setVoterForm((p) => ({ ...p, name: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-[#FFCB05]/40"
                  style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
                  required />
                <input type="email" placeholder="you@umich.edu" value={voterForm.email}
                  onChange={(e) => setVoterForm((p) => ({ ...p, email: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-[#FFCB05]/40"
                  style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
                  required />
                <div className="flex justify-end gap-3 pt-2">
                  <button type="button" onClick={() => { setShowVoterModal(false); setPendingPitchId(null); }}
                    className="px-4 py-2.5 text-sm font-medium text-white/35 hover:text-white/60 transition-colors">Cancel</button>
                  <button type="submit" className="px-5 py-2.5 rounded-xl text-sm font-bold text-[#0B1A3B] transition-colors"
                    style={{ background: "#FFCB05" }}>
                    Continue to Vote
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </>
  );
}
